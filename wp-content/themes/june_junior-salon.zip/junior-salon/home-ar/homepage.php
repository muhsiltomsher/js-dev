<section id="shop">
  <div class="container mx-auto text-center">

    <?php get_template_part('components-ar/shopby-category'); ?>
    <?php get_template_part('components-ar/shopby-brands'); ?>
    <?php get_template_part('components-ar/products/tab-wrapper'); ?>
    <?php get_template_part('components-ar/shopby-age'); ?>
    <?php get_template_part('components-ar/products/popular-picks'); ?>
    <?php get_template_part('components-ar/home-banner-category'); ?>
    <?php get_template_part('components-ar/home-features-banner'); ?>
    <?php get_template_part('components-ar/testimonials-listing'); ?>

  </div>
</section>
<script>
  const ajaxurl = "<?php echo esc_url(admin_url('admin-ajax.php')); ?>";

  document.addEventListener("DOMContentLoaded", function () {
    // entire lazy load logic removed
  });
</script>
