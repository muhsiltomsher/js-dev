<!-- hero-slider.php -->
  <?php 
            echo do_shortcode('[smartslider3 slider="1"]');  // Ensure the slider ID is correct (e.g., "1")
        ?>