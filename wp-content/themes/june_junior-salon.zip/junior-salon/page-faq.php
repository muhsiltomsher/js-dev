<?php
/**
 * Template Name: FAQ Page
 */
include get_template_directory() . '/layouts/header.php';

?>

<main>
    <div class="container mx-auto py-12">


    <?php

echo do_shortcode('[wptabs id="527"]');

?>
</div> </main>
<?php

 include get_template_directory() . '/layouts/footer.php'; ?>