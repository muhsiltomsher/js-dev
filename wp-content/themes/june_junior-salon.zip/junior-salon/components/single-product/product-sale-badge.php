<?php if ($product->is_on_sale()) : ?>
  <div class="absolute top-4 left-4 bg-red-600 text-white text-xs uppercase px-2 py-1 rounded">
    Sale
  </div>
<?php endif; ?>
